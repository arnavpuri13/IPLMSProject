﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using HMS.DAL;
using HMS.Entity;
using HMS.Exception;

namespace HMS.BLL
{
    /// <summary>
    /// Employee ID : 161696
    /// Employee Name : Arnav Puri
    /// Description : This class will have Business Logic for Hospital Management System
    /// Date of Modification : 17th Oct 2018
    /// </summary>
    public class PatientValidations
    {
        PatientOperations patOperation;
        public DataTable LoadPatient_BLL()
        {
            DataTable dtDept;
            try
            {
                patOperation = new PatientOperations();
                dtDept = patOperation.LoadPatient();
            }
            catch (SqlException se)
            {

                throw se;
            }
            catch (PatientException ex)
            {

                throw ex;
            }
            return dtDept;
        }

        public DataTable GetPatient_BLL()
        {
            DataTable dtEmp;
            try
            {
                patOperation = new PatientOperations();
                dtEmp = patOperation.GetPatient_DAL();
            }
            catch (SqlException se)
            {

                throw se;
            }
            catch (PatientException ex)
            {

                throw ex;
            }
            return dtEmp;
        }

        public bool validatePat(Patient newpat)
        {
            bool isValidPat = true;
            StringBuilder sbError = new StringBuilder();
            try
            {
                if (newpat.PatientFName == string.Empty || newpat.PatientLName == string.Empty || 
                    newpat.PatientGender == string.Empty || newpat.PatientAddr == string.Empty || 
                    newpat.PatientCity == string.Empty || newpat.PatientState == string.Empty ||
                    Convert.ToString(newpat.PatientPINCode) == string.Empty || Convert.ToString(newpat.PatientPhone) == string.Empty)
                {
                    isValidPat = false;
                    sbError.Append("Please enter All the details before Continuing.");
                }

                if(newpat.PatientPhone < 1000000000 || newpat.PatientPhone > 9999999999 )
                {
                    isValidPat = false;
                    sbError.Append("Please enter a 10 digit Phone Number.");
                }

                if (newpat.PatientPINCode < 100000 || newpat.PatientPINCode > 999999)
                {
                    isValidPat = false;
                    sbError.Append("Please enter a 6 digit PIN Code.");
                }


                if (!isValidPat) throw new PatientException(sbError.ToString());
            }
            catch (PatientException ex)
            { throw ex; }

            return isValidPat;
        }
        public int AddPatient_BLL(Patient newPat)
        {
            int rowsAffected = 0;
            PatientOperations operationObj;
            try
            {
                if (validatePat(newPat))
                {
                    operationObj = new PatientOperations();
                    rowsAffected = operationObj.AddPatient_DAL(newPat);
                }
            }
            catch (PatientException ex) { throw ex; }
            catch (SqlException se) { throw se; }
            catch (SystemException ex) { throw ex; }
            return rowsAffected;

        }
    }
}
