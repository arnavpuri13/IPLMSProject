﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMS.Entity
{
    /// <summary>
    /// Employee ID : 161696
    /// Employee Name : Arnav Puri
    /// Description : This is an entity class for Hospital Management System
    /// Date of Modification : 17th Oct 2018
    /// </summary>
    public class Patient
    {
        //To get or set Patient ID
        public int PatientID { get; set; }
        //To get or set Patient First Name
        public string PatientFName { get; set; }
        //To get or set Patient Last Name
        public string PatientLName { get; set; }
        //To get or set Patient Gender
        public string PatientGender { get; set; }
        //To get or set Patient Address
        public string PatientAddr { get; set; }
        //To get or set Patient City 
        public string PatientCity { get; set; }
        //To get or set Patient State
        public string PatientState { get; set; }
        //To get or set Patient PIN Code
        public int PatientPINCode { get; set; }
        //To get or set Patient Patient Phone Number
        public long PatientPhone { get; set; }
    }
}
