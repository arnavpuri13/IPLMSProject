﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMS.Exception
{
    /// <summary>
    /// Employee ID : 161696
    /// Employee Name : Arnav Puri
    /// Descrition : This is an user defined exception class for Hospital Management System
    /// Date of Modification : 17th Oct 2018
    /// </summary>
    public class PatientException: ApplicationException
    {
        //Default Constructor
        public PatientException()
            : base()
        { }

        //Parameterized constructor with message parameter
        public PatientException(string message)
            : base(message)
        { }
    }
}
