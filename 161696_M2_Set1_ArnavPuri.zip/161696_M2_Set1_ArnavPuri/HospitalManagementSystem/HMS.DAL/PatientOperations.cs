﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using HMS.Entity;


namespace HMS.DAL
{
    /// <summary>
    /// Employee ID : 161696
    /// Employee Name : Arnav Puri
    /// Description : This class will provide CRUD operations for Hospital Management System
    /// Date of Modification : 17th Oct 2018
    /// </summary>
    public class PatientOperations
    {
        static string patConnStr = ConfigurationManager.ConnectionStrings["conStr"].ToString();
        static SqlConnection patConnObj;
        SqlCommand patCommand;
        DataTable dtPat;
        SqlDataReader patReader = null;
        public PatientOperations()
        {
            patConnObj = new SqlConnection();
            patConnObj.ConnectionString = patConnStr;
        }
        public DataTable LoadPatient()
        {

            try
            {
                dtPat = new DataTable();
                patCommand = new SqlCommand("ArnavP.usp_GetPatients", patConnObj);
                patCommand.CommandType = CommandType.StoredProcedure;
                patConnObj.Open();
                patReader = patCommand.ExecuteReader();
                dtPat.Load(patReader);

            }
            catch (SqlException)
            {
                throw;

            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                patReader.Close();
                if (patConnObj.State == ConnectionState.Open) patConnObj.Close();
            }
            return dtPat;
        }

        public int AddPatient_DAL(Patient pat)
        {
            int rowsAffected = 0;
            try
            {
                //Adding By value to the table
                patCommand = new SqlCommand("ArnavP.usp_AddPatients", patConnObj);
                patCommand.CommandType = CommandType.StoredProcedure;//,@eLoc,@ePh,@eDeptId
                patCommand.Parameters.AddWithValue("@eFName", pat.PatientFName);
                patCommand.Parameters.AddWithValue("@@pLName", pat.PatientLName);
                patCommand.Parameters.AddWithValue("@pGender", pat.PatientGender );
                patCommand.Parameters.AddWithValue("@pAddr", pat.PatientAddr );
                patCommand.Parameters.AddWithValue("@pCity", pat.PatientCity);
                patCommand.Parameters.AddWithValue("@pState", pat.PatientState);
                patCommand.Parameters.AddWithValue("@pPIN", pat.PatientPINCode);
                patCommand.Parameters.AddWithValue("@pPhone", pat.PatientPhone);


                patConnObj.Open();
                rowsAffected = patCommand.ExecuteNonQuery();

            }
            catch (SqlException)
            {

                throw;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (patConnObj.State == ConnectionState.Open) patConnObj.Close();
            }
            return rowsAffected;

        }

        public DataTable GetPatient_DAL()
        {
            try
            {
                dtPat = new DataTable();
                //patCommand = new SqlCommand("Geetha.usp_DisplayEmployee", patConnObj);
                patCommand.CommandType = CommandType.StoredProcedure;
                patConnObj.Open();
                patReader = patCommand.ExecuteReader();
                if (patReader.HasRows)
                {
                    dtPat.Load(patReader);
                }
            }
            catch (SqlException ex)
            {

                throw;
            }
            catch (Exception ex)
            {

                throw;
            }
            finally
            {
                patReader.Close();
                if (patConnObj.State == ConnectionState.Open) patConnObj.Close();
            }
            return dtPat;
        }

    }
}
