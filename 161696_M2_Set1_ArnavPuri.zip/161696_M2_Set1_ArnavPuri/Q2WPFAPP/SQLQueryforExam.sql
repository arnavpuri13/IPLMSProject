use Sep19CHN

create table ArnavP.Patient
(
PatId int identity(100,1),
PatFName varchar(30),
PatLName varchar(30),
PatGender varchar(10),
PatAddr varchar(50),
PatCity varchar(30),
PatState varchar(30),
PatPin int,
EmpContact bigint,
)

create proc ArnavP.uspNextPatientId
as
begin
select IDENT_CURRENT('ArnavP.Patient') +IDENT_Incr('ArnavP.Patient') 
end

create proc ArnavP.usp_GetPatients
as
begin
	select * from ArnavP.Patient
end

create proc ArnavP.usp_AddPatients
(
@pId int output,
@pFName varchar(30),
@pLName varchar(30),
@pGender varchar(10),
@pAddr varchar(50),
@pCity varchar(30),
@pState varchar(30),
@pPIN int,
@pPhone bigint
)
as
BEGIN
	insert into ArnavP.Patient
	values(@pFName ,@pLName,@pGender,@pAddr,@pCity,@pState,@pPIN,@pPhone)
	set @pId = SCOPE_IDENTITY()
END

create proc ArnavP.usp_FindMAHAPatient
AS
BEGIN
	select * from ArnavP.Patient
	where PatState = 'maharashtra'
END

exec ArnavP.usp_AddPatients '101','Arnav','Puri','Male','address','city','Maharashtra','123456','1234567890' 

