﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;

namespace Q2WPFAPP
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btn_Search_Click(object sender, RoutedEventArgs e)
        {
           //For Showing data for Maharashtra only
            SqlConnection conObj = new SqlConnection(@"Data Source=ndamssql\sqlilearn;Initial Catalog=Sep19CHN;User ID=sqluser;Password=sqluser");
            SqlCommand searchCmd = new SqlCommand("ArnavP.usp_FindMAHAPatient", conObj);
            searchCmd.CommandType = CommandType.StoredProcedure;
            SqlDataReader rdr = null;
            conObj.Open();
            rdr = searchCmd.ExecuteReader();
            DataTable dtPat = new DataTable();

            if (rdr.HasRows)
            {
                dtPat.Load(rdr);
                dt_gr.ItemsSource = dtPat.DefaultView;

            }
            else MessageBox.Show("No records found");


            rdr.Close();
            conObj.Close();
        }
    }
}
