use Sep19CHN

create table ArnavP.Trainee1
(
Trainee_ID int primary key,
Trainee_Mod_Name varchar(30),
Trainee_Batch_Name varchar(30),
Trainee_Comments varchar(200)
)

create proc ArnavP.usp_AddTrainees1
(
@tId int,
@tMod varchar(30),
@tBatch varchar(30),
@tComm varchar(200)
)
as
BEGIN
	insert into ArnavP.Trainee1
	values(@tId ,@tMod,@tBatch,@tComm)
END

select * from ArnavP.Trainee1