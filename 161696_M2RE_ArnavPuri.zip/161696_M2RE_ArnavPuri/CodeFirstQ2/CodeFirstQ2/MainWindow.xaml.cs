﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;

namespace CodeFirstQ2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnShow_Click(object sender, RoutedEventArgs e)
        {
            Sep19CHNEntities1 Context = new Sep19CHNEntities1();
            var data = Context.Trainee1.Where(t => t.Trainee_Batch_Name.ToLower() == ".net");
            List<Trainee1> tList = new List<Trainee1>();
            tList = data.ToList<Trainee1>();

            if (tList.Count > 0)
            {
                dt_gr.ItemsSource = data.ToList();

            }
            else MessageBox.Show("No records found");
        }

    }
}

