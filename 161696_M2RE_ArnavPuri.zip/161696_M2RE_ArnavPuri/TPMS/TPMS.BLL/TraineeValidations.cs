﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TPMS.Entity; //reference to TPMS Entity Class
using TPMS.Exception; //reference to TPMS Exception Class
using TPMS.DAL; //Reference To TPMS DAL Class
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace TPMS.BLL
{
    /// <summary>
    /// Employee ID : 161696
    /// Employee Name : Arnav Puri
    /// Description : This class will have Business Logic for Trainee Performance Management System
    /// Date of Modification : 27th Oct 2018
    /// </summary>
    public class TraineeValidations
    {

        public bool validateTrainee(Trainee newtrainee)
        {
            bool isValidTrainee = true;
            StringBuilder sbError = new StringBuilder();
            try
            {
                if (Convert.ToString(newtrainee.TraineeId) == string.Empty || newtrainee.Modname == string.Empty ||
                    newtrainee.BatchName == string.Empty || newtrainee.Comments == string.Empty)
                   {
                    isValidTrainee = false;
                    sbError.Append("Please enter All the details before Continuing.");
                }

                if (newtrainee.TraineeId < 100000 || newtrainee.TraineeId > 999999)
                {
                    isValidTrainee = false;
                    sbError.Append("Please enter a 6 digit Trainee ID.\n");
                }

                if (newtrainee.Modname.ToLower() != "module 1" && newtrainee.Modname.ToLower() != "module 2" && newtrainee.Modname.ToLower() != "module 3" && newtrainee.Modname.ToLower() != "module 4")
                {
                    isValidTrainee = false;
                    sbError.Append("Please Enter 'Module 1' or 'Module 2' or 'Module 3' or 'Module 4' for your Module Name.\n");
                }

                if (newtrainee.BatchName.ToLower() != ".net" && newtrainee.BatchName.ToLower() != "java" && newtrainee.BatchName.ToLower() != "bi")
                {
                    isValidTrainee = false;
                    sbError.Append("Please Enter '.Net' or 'Java' or 'BI' for your Batch Name.\n");
                }

                if (!isValidTrainee) throw new TraineeException(sbError.ToString());
            }
            catch (TraineeException ex)
            { throw ex; }

            return isValidTrainee;
        }

        public int AddTrainee_BLL(Trainee newtrainee)
        {
            int rowsAffected = 0;
            try
            {
                if (validateTrainee(newtrainee))
                {
                    rowsAffected = TraineeOperations.AddTrainee_DAL(newtrainee);
                }
            }
            catch (TraineeException ex) { throw ex; }
            catch (SqlException se) { throw se; }
            catch (SystemException ex) { throw ex; }
            return rowsAffected;

        }
    }
}
