﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TPMS.Entity; //Reference for TPMS Entity Class
using TPMS.Exception; //Reference for TPMS Exception Class
using TPMS.BLL; // Reference for TPMS BLL Class
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace TPMS.PL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                TraineeValidations bllObj = new TraineeValidations();
                Trainee newTrainee = new Trainee();

                newTrainee.TraineeId = Convert.ToInt32(txtEmpID.Text);
                newTrainee.Modname = txtModName.Text;
                newTrainee.BatchName = txtBatchname.Text;
                newTrainee.Comments = txtComm.Text;

                int rowsAffected = bllObj.AddTrainee_BLL(newTrainee);
                if (rowsAffected > 0)
                {
                    MessageBox.Show("Trainee Added !!");
                }
                else MessageBox.Show("Error!!! Trainee Record not Added");
            }
            catch (TraineeException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);

            }

        }
    }
}
