﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPMS.Exception
{
    /// <summary>
    /// Employee ID : 161696
    /// Employee Name : Arnav Puri
    /// Descrition : This is an user defined exception class for Trainee Performance Management System
    /// Date of Modification : 27th Oct 2018
    /// </summary>
    public class TraineeException : ApplicationException
    {
        //Default Constructor
        public TraineeException()
            : base()
        { }

        //Parameterized constructor with message parameter
        public TraineeException(string message)
            : base(message)
        { }
    }
}
