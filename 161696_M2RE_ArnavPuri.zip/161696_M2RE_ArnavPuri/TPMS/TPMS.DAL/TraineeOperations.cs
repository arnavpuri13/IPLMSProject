﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TPMS.Entity;
using TPMS.Exception;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace TPMS.DAL
{
    /// <summary>
    /// Employee ID : 161696
    /// Employee Name : Arnav Puri
    /// Description : This class will provide CRUD operations for Trainee Performance Management System
    /// Date of Modification : 27th Oct 2018
    /// </summary>
    public class TraineeOperations
    {
        //Function to add patient in Database
        public static int AddTrainee_DAL(Trainee t)
        {
            int rowsAffected = 0;
            try
            {
                //Creating command object
                SqlCommand tCommand = DataConnection.GenerateCommand();

                //Assigning command text
                tCommand.CommandText = "ArnavP.usp_AddTrainees1";

                //Adding parameters to command
                tCommand.Parameters.AddWithValue("@tId", t.TraineeId);
                tCommand.Parameters.AddWithValue("@tMod", t.Modname);
                tCommand.Parameters.AddWithValue("@tBatch", t.BatchName);
                tCommand.Parameters.AddWithValue("@tComm", t.Comments);

                //Executing command
                tCommand.Connection.Open();
                rowsAffected = tCommand.ExecuteNonQuery();
                tCommand.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return rowsAffected;
        }
    }
}
