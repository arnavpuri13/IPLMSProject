﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPMS.Entity
{
    /// <summary>
    /// Employee ID : 161696
    /// Employee Name : Arnav Puri
    /// Description : This is an entity class for Trainee Performance Management System
    /// Date of Modification : 27th Oct 2018
    /// </summary>
    public class Trainee
    {
        //Get or set Trainee ID
        public int TraineeId { get; set; }
        //Get or set Trainee Module Name
        public string Modname { get; set; }
        //Get or set Trainee Batch Name
        public string BatchName { get; set; }
        //Get or set Comments on Trainee
        public string Comments { get; set; }
    }
}
